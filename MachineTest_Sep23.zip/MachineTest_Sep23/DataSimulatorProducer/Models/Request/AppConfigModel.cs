﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Models.Request
{
    internal class AppConfigModel
    {
        public string PostCompletedRequest_URL { get; set; }
        public string GetPendingRequest_URL { get; set; }
        public string GetStatusFromAPI_URL {  get; set; }
        public string CheckDeviceActive_URL {  get; set; }

    }
}
