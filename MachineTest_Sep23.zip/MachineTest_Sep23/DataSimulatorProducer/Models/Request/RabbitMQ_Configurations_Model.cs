﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Models.Request
{
    public class RabbitMQ_Configurations_Model
    {
        public string HostName { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string queue1Name { get; set; }
            
    }
}
