﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Models.Response
{
    internal class DeviceResponseModel
    {
        //public Guid Id { get; set; }
        public string DeviceCode {  get; set; }
        public DateTime TimeStamp { get; set; }
        public int X {  get; set; }
        public int Y { get; set; }
        public string Status {  get; set; }

    }
}
