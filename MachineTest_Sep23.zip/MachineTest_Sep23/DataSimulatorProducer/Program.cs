﻿using DataSimulatorProducer.Interfaces;
using DataSimulatorProducer.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace DataSimulatorProducer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            var _producer = host.Services.GetService<IProducer>();
            //_producer.StartProcessing();
            _producer.StartDataGeneration();
            //string deviceCode = "777";
            //_producer.GetStatusFromAPI(deviceCode);
            host.Run();
        }
        public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args).ConfigureServices((hostContext, services) =>
        {
            services.AddSingleton<IConfigurationService, ConfigurationService>();
            services.AddScoped<IProducer, Producer>();

        }).ConfigureAppConfiguration((hostingContext, config) =>
        {
            config.AddJsonFile("appSettings.json", optional: false, reloadOnChange: true);
        });
    }
}