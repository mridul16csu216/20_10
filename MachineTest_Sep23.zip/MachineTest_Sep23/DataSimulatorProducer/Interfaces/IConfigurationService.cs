﻿using DataSimulatorProducer.Models.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Interfaces
{
    internal interface IConfigurationService
    {
        public RabbitMQ_Configurations_Model RabbitMQconfigurationModel { get; }
        public AppConfigModel appConfigModel {  get; } 
    }
}
