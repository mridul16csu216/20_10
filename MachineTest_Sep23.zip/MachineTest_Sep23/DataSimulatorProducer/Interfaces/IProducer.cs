﻿using DataSimulatorProducer.Models.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Interfaces
{
    internal interface IProducer
    {
        public Task<List<DeviceRequestModel>> GetPendingRequestFromAPI();
        public bool RequestCompletedPostToAPI(string message);
        public int GenerateRandomNumber(int MinValue, int MaxValue);
        public Task<string> GetStatusFromAPI(string deviceCode);
        public Task<string> StartDataGeneration();
        public bool? CheckDeviceActive(string deviceCode);
        public Task StartProcessing();

    }
}
