﻿using DataSimulatorProducer.Interfaces;
using DataSimulatorProducer.Models.Request;
using DataSimulatorProducer.Models.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Services
{
    internal class Producer : IProducer
    {
        private IConfigurationService _configurationService;
        private readonly HttpClient httpClient;
        private readonly object lockObject = new object();
        private int getPendingRequestInterval = 6000; 
        private int startDataGenerationInterval = 3000;
        private ConnectionFactory _connectionFactory;
        private IConnection _connection;
        private IModel _channel;
        DateTime recordedTime = DateTime.MinValue;
        List<DeviceRequestModel> currentPendingRequests = new List<DeviceRequestModel>();
        TimeSpan TimeInterval1 = TimeSpan.FromSeconds(6);
        public Producer(IConfigurationService configurationService)
        {
            httpClient = new HttpClient();
            _configurationService = configurationService;
        }
        private bool PublishJson()
        {
            return true;
        }
        public bool RequestCompletedPostToAPI(string message)
        {
            //Console.WriteLine(message);
            var data = new { DeviceCode = message };
            var apiUrl = _configurationService.appConfigModel.PostCompletedRequest_URL + "/" + message;
            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = httpClient.PostAsync(apiUrl, content).Result;
            if (response.IsSuccessStatusCode)
            {
                //var responseContent = response.Content.ReadAsStringAsync().Result;
                Console.WriteLine("API Update Call received");
                return true;
            }
            else
            {
                //var responseContent = response.Content.ReadAsStringAsync().Result;
                Console.WriteLine("API Update Call not received");
                return false;
            }
        }
        //private DeviceResponseModel GenerateData(DeviceRequestModel deviceRequestModel ,DateTime currentTime)
        //{
        //    bool value = GetStatusFromAPI(deviceRequestModel.DeviceCode);
        //    var deviceData = new DeviceResponseModel
        //    {
        //        DeviceCode = deviceRequestModel.DeviceCode,
        //        TimeStamp = currentTime,
        //        X = GenerateRandomNumber(1,9),
        //        Y = GenerateRandomNumber(1,9),
        //        Status = value,
        //    };
        //    string Json = JsonConvert.SerializeObject(deviceData, Formatting.Indented);
        //    Console.WriteLine(Json);
        //    return deviceData;
        //}
        public async Task<string> GetStatusFromAPI(string deviceCode)
        {
            var apiUrl = _configurationService.appConfigModel.GetStatusFromAPI_URL + "/" + deviceCode;
            var response = httpClient.GetAsync(apiUrl).Result;
            //Console.WriteLine(response);
            if(response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadFromJsonAsync<ServiceResponseModel>();
                var Object = responseContent.Result.ToString();
                return Object.ToString();
            }
            else
            {
                return null; 
            }
        }
        public async Task<List<DeviceRequestModel>> GetPendingRequestFromAPI()
        {
            try
            {
                var apiUrl = _configurationService.appConfigModel.GetPendingRequest_URL;
                var response = httpClient.GetAsync(apiUrl).Result;
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var responseContent = await response.Content.ReadFromJsonAsync<ServiceResponseModel>();
                        var Object = responseContent.Result.ToString();
                        List<DeviceRequestModel> listResponse = JsonConvert.DeserializeObject<List<DeviceRequestModel>>(responseContent.Result.ToString());
                        List<DeviceRequestModel> pendingRequestsList = new List<DeviceRequestModel>();
                        foreach (var deviceRequest in listResponse)
                        {
                            // Check if a DeviceRequestModel with the same id exists in pendingRequestsList
                            bool isDuplicate = pendingRequestsList.Any(existingRequest => existingRequest.Id == deviceRequest.Id);

                            if (!isDuplicate)
                            {
                                // Add the deviceRequest to pendingRequestsList
                                pendingRequestsList.Add(deviceRequest);
                                
                            }
                        }
                        Console.WriteLine("6 Seconds");
                        return pendingRequestsList;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in fetching pending requests");
                Console.WriteLine(ex);
                return null;
            }
        }
        private void InitializeRabbitMQ()
        {
            string queue1Name = _configurationService.RabbitMQconfigurationModel.queue1Name;
            var _connectionFactory = new ConnectionFactory()
            {
                HostName = _configurationService.RabbitMQconfigurationModel.HostName,
                Port = _configurationService.RabbitMQconfigurationModel.Port,
                UserName = _configurationService.RabbitMQconfigurationModel.UserName,
                Password = _configurationService.RabbitMQconfigurationModel.Password
            };
            _connection = _connectionFactory.CreateConnection();
            _channel = _connection.CreateModel();
            _channel.ExchangeDeclare(exchange: "exch1", type: ExchangeType.Fanout);
            _channel.QueueBind(queue: queue1Name, exchange: "exch1", routingKey: "");
        }
        private void PublishToRabbitMQ(string Json)
        {
            if (_connectionFactory == null || _connection == null || _channel == null)
            {
                // Initialize the RabbitMQ connection and channel if not already done.
                InitializeRabbitMQ();
            }
            var body = Encoding.UTF8.GetBytes(Json);
            _channel.BasicPublish(exchange: "exch1", routingKey: "", basicProperties: null, body: body);
        }
        public int GenerateRandomNumber(int MinValue, int MaxValue)
        {
            if (MinValue >= MaxValue)
            {
                throw new ArgumentException("minValue must be less than maxValue");
            }
            Random random = new Random();
            int n = random.Next(MinValue, MaxValue);
            return n;
        }
        public async Task<string> StartDataGeneration()
        {
            try
            {
                while (true)
                {
                    DateTime dateCreated = DateTime.Now;
                    TimeSpan timeSinceLastRequest = dateCreated - recordedTime;

                    if (timeSinceLastRequest >= TimeInterval1)
                    {
                        currentPendingRequests = await GetPendingRequestFromAPI();
                        recordedTime = DateTime.Now;
                        Console.WriteLine("Inside Loop");
                    }
                    //List<DeviceRequestModel> currentPendingRequests = await GetPendingRequestFromAPI();
                    foreach (var deviceRequestModel in currentPendingRequests)
                    {
                        bool? V1 = CheckDeviceActive(deviceRequestModel.DeviceCode);
                        if (V1 == true)
                        {
                            if (dateCreated > deviceRequestModel.StartTime && dateCreated < deviceRequestModel.EndTime)
                            {
                                DateTime currentTime = DateTime.Now;
                                string value = await GetStatusFromAPI(deviceRequestModel.DeviceCode);
                                //GenerateData(deviceRequestModel, currentTime);
                                var deviceData = new DeviceResponseModel
                                {
                                    DeviceCode = deviceRequestModel.DeviceCode,
                                    TimeStamp = currentTime,
                                    X = GenerateRandomNumber(1, 9),
                                    Y = GenerateRandomNumber(1, 9),
                                    Status = value,
                                };
                                string Json = JsonConvert.SerializeObject(deviceData, Formatting.Indented);
                                //PublishToRabbitMQ(Json);
                                Console.WriteLine(Json);
                            }
                        }
                        RequestCompletedPostToAPI(deviceRequestModel.DeviceCode) ;
                    }
                    //recordedTime = DateTime.Now;
                    Thread.Sleep(3000);
                    Console.WriteLine("3 Seconds");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            return "Completed";
        }
        public bool? CheckDeviceActive(string deviceCode)
        {
            try
            {
                var apiUrl = _configurationService.appConfigModel.CheckDeviceActive_URL + "/" + deviceCode;
                var response = httpClient.GetAsync(apiUrl).Result;
                if (response.IsSuccessStatusCode)
                {
                    var responseContent = response.Content.ReadFromJsonAsync<ServiceResponseModel>();
                    var Object = responseContent.Result.Result.ToString();
                    //Console.WriteLine(Object);
                    if (Object == "True")
                    {
                        return true;
                    }
                    else if (Object == "False")
                    {
                        return false;
                    }
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
               
            }
            return null;
        }
        public async Task StartProcessing()
        {
            var pendingRequestTask = GetPendingRequestFromAPI();
            var dataGenerationTask = StartDataGeneration();

            await Task.WhenAll(pendingRequestTask, dataGenerationTask);
        }

        
    }
}
