﻿using DataSimulatorProducer.Interfaces;
using DataSimulatorProducer.Models.Request;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSimulatorProducer.Services
{
    internal class ConfigurationService : IConfigurationService
    {
        private readonly AppConfigModel _appConfigModel;
        private readonly RabbitMQ_Configurations_Model _rabbitMQ_Configurations_Model;
        AppConfigModel IConfigurationService.appConfigModel => _appConfigModel;
        RabbitMQ_Configurations_Model IConfigurationService.RabbitMQconfigurationModel => _rabbitMQ_Configurations_Model;
        
        public ConfigurationService(IConfiguration configuration)
        {
            _appConfigModel = configuration.Get<AppConfigModel>();
            _rabbitMQ_Configurations_Model = configuration.GetSection("RabbitMQ Configurations").Get<RabbitMQ_Configurations_Model>();
        }
    }
}
