﻿using Microsoft.Extensions.Configuration;
using RabbitMQConsumerForDeviceData.Interface;
using RabbitMQConsumerForDeviceData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQConsumerForDeviceData.Services
{
    internal class ConfigurationService : IConfigurationService
    {
        private readonly AppConfigModel _appConfigModel;
        AppConfigModel IConfigurationService.appConfigModel => _appConfigModel;

        public ConfigurationService(IConfiguration configuration)
        {
            _appConfigModel = configuration.GetSection("ConnectionStrings").Get<AppConfigModel>();
        }
    }
}
