﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQConsumerForDeviceData.Interface;
using RabbitMQConsumerForDeviceData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQConsumerForDeviceData.Services
{
    internal class Consumer : IConsumer
    {
        private readonly ConnectionFactory factory;
        private IConnection connection;
        private IModel channel;
        private readonly HttpClient httpClient;
        private IConfigurationService _configurationService;
        public Consumer(IConfigurationService configurationService)
        {
            factory = new ConnectionFactory
            {
                HostName = "10.167.96.47",
                Port = 5672,
                UserName = "admin",
                Password = "admin"
            };
            httpClient = new HttpClient();
            _configurationService = configurationService;
        }
        public void StartConsuming()
        {
            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();

            channel.QueueDeclare(queue: _configurationService.appConfigModel.queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, eventArgs) =>
            {
                byte[] body = eventArgs.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                var data = JsonConvert.DeserializeObject<DataModel>(message);

                //Console.WriteLine($"Received message: DeviceCode: {data.DeviceCode}, Parameter: {data.Parameter}, DateCreated: {data.DateCreated}");
                var apiResponse = PostDataToApi(message);
                Console.WriteLine("API Response: " + apiResponse);
            };

            channel.BasicConsume(queue: _configurationService.appConfigModel.queueName, autoAck: true, consumer: consumer);

            Console.WriteLine("Press [Enter] to exit.");
            Console.ReadLine();
        }
        public string PostDataToApi(string message)
        {
            {
                Console.WriteLine(message);
                var apiUrl = _configurationService.appConfigModel.API_URL;
                var content = new StringContent(message, Encoding.UTF8, "application/json");

                var response = httpClient.PostAsync(apiUrl, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = response.Content.ReadAsStringAsync().Result;
                    return "API call was successful. Response: " + responseContent;
                }
                else
                {
                    return "API call failed: " + response.ReasonPhrase;
                }
            }

        }
    }
}
