﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQConsumerForDeviceData.Models
{
    internal class AppConfigModel
    {
        public string API_URL { get; set; }
        public string queueName { get; set; }
    }
}
