﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQConsumerForDeviceData.Models;

namespace RabbitMQConsumerForDeviceData.Interface
{
    internal interface IConfigurationService
    {
        public AppConfigModel appConfigModel { get; }
    }
}
