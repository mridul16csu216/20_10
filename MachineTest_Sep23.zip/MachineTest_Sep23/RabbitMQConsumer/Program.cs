﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RabbitMQConsumerForDeviceData.Interface;
using RabbitMQConsumerForDeviceData.Services;

namespace RabbitMQConsumer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            var _consumerService = host.Services.GetService<IConsumer>();
            _consumerService?.StartConsuming();
            host.Run();
        }
        public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args).ConfigureServices((hostContext, services) =>
        {
            services.AddScoped<IConsumer, Consumer>();
            services.AddSingleton<IConfigurationService, ConfigurationService>();

        }).ConfigureAppConfiguration((hostingContext, config) =>
        {
            config.AddJsonFile("appSettings.json", optional: false, reloadOnChange: true);
        });
    }
}