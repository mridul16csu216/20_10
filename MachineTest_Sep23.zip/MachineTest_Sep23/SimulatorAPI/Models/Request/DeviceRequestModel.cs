﻿namespace SimulatorAPI.Models.Request
{
    public class DeviceRequestModel
    {
        public string DeviceName {  get; set; }
        public string DeviceCode { get; set; }
        public DateTime StartTime {  get; set; }
        public DateTime EndTime { get; set; }
        public DateTime DateCreated { get; set; }
        public bool IsPublishingRequestCompleted {  get; set; }

    }
}
