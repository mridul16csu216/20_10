﻿namespace SimulatorAPI.Models.Response
{
    public class ServiceResponseModel
    {
        private bool _status = false;
        public bool Status { get => _status; set => _status = value; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }

        public int StatusCode { get => Status ? 200 : 400; }
        public dynamic Result { get; set; }
    }
}
