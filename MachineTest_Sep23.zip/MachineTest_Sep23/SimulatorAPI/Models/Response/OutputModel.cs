﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace SimulatorAPI.Models.Response
{
    public class OutputModel
    {
        public string DeviceCode {  get; set; }
        public DateTime TimeStamp { get; set; }
        public int X {  get; set; }
        public int Y { get; set; }
        public bool Status {  get; set; }
        
    }
}
