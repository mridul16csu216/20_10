﻿using Microsoft.EntityFrameworkCore;
using SimulatorAPI.Entity;

namespace SimulatorAPI.Data
{
    public class DbContextClass :DbContext 
    {
        protected readonly IConfiguration Configuration;

        public DbContextClass(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(Configuration.GetConnectionString("DatabaseConnectionString"));
            options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
        }

        public DbSet<DeviceDataEntity> tbl_Device_Data { get; set; }
        public DbSet<DevicesEntity> tbl_Devices { get; set; }
        public DbSet<DeviceStatusEntity> tbl_Device_Status	{ get; set; }
        public DbSet<DeviceActivityEntity> tbl_Device_Active_Status {  get; set; }
    }
}
