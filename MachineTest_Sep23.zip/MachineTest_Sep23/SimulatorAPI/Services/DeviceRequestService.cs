﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SimulatorAPI.Data;
using SimulatorAPI.Entity;
using SimulatorAPI.Interfaces;
using SimulatorAPI.Models.Request;
using SimulatorAPI.Models.Response;

namespace SimulatorAPI.Services
{
    public class DeviceRequestService : IDeviceRequestService
    {
        private readonly IConfiguration _configuration;
        DbContextClass _dbContextClass;
        public DeviceRequestService(IConfiguration configuration, DbContextClass dBContextClass)
        {
            _configuration = configuration;
            _dbContextClass = dBContextClass;
        }
        public async Task<ServiceResponseModel> AddDeviceRequestAsync(DeviceRequestModel model)
        {
            ServiceResponseModel responseModel = new ServiceResponseModel();
            try
            {
                var deviceCode = model.DeviceCode;
                var checkDevice = await _dbContextClass.tbl_Devices.Where(d => d.DeviceCode == deviceCode).FirstOrDefaultAsync(); // Check if device already exists
                if (checkDevice == null)
                {
                    var Task1 = await _dbContextClass.tbl_Devices.AnyAsync(x => x.DeviceCode.ToLower() == model.DeviceCode.ToLower() && model.StartTime >= x.StartTime && model.EndTime <= x.EndTime);
                    if (Task1)
                    {
                        responseModel.Status = false;
                        responseModel.ErrorMessage = "Request already exists";
                    }
                    else
                    {
                        var publishRequest = new DevicesEntity()
                        {
                            DeviceName = model.DeviceName,
                            DeviceCode = model.DeviceCode,
                            DateCreated = DateTime.Now,
                            StartTime = model.StartTime,
                            EndTime = model.EndTime,
                            IsPublishingRequestCompleted = false
                        };
                        if (publishRequest.StartTime >= publishRequest.EndTime)
                        {
                            responseModel.Status = false;
                            responseModel.ErrorMessage = "Invalid Time Constraints" + "The start date should be less than End date";
                        }
                        else
                        {
                            var addStatusTableElements = new DeviceStatusEntity()
                            {
                                Id = Guid.NewGuid(),
                                DeviceCode = model.DeviceCode,
                                TimeStamp = DateTime.Now,
                                Status = false
                            };
                            var deviceActiveElements = new DeviceActivityEntity()
                            {
                                DeviceCode = model.DeviceCode,
                                IsRunning = true,
                                TimeStamp = DateTime.Now
                               
                            };
                            _dbContextClass.tbl_Device_Active_Status.Add(deviceActiveElements);
                            _dbContextClass.tbl_Device_Status.Add(addStatusTableElements);
                            _dbContextClass.tbl_Devices.Add(publishRequest);
                            await _dbContextClass.SaveChangesAsync();
                            responseModel.Status = true;
                            responseModel.SuccessMessage = "Request Added Successfully";
                        }
                    }
                }
                else
                {
                    responseModel.Status = false;
                    responseModel.ErrorMessage = "Device Code already exists";
                }
                
            }
            catch (Exception ex)
            {
                responseModel.ErrorMessage = "Failed to add publish request";
                responseModel.Status = false;
            }
            return responseModel;
        }
        public async Task<ServiceResponseModel> GetPendingRequestsAsync()
        {
            ServiceResponseModel responseModel = new ServiceResponseModel();
            var devicePendingRequestList = await _dbContextClass.tbl_Devices.Where(request => request.IsPublishingRequestCompleted != true).ToListAsync();
            
            
            try
            {
                if(devicePendingRequestList == null)
                {
                    responseModel.Status = true;
                    responseModel.SuccessMessage = "No Pending Requests";
                }
                else
                {
                    responseModel.Status = true;
                    responseModel.SuccessMessage = "OK";
                    responseModel.Result = devicePendingRequestList;
                }
            }
            catch 
            {
                responseModel.Status = false;
            }
            return responseModel;
        }
        public async Task<ServiceResponseModel> UpdateRequestToCompletedAsync(string DeviceCode)
        {
            ServiceResponseModel responseModel = new ServiceResponseModel();
            var RequestToUpdate = await _dbContextClass.tbl_Devices.Where(r => r.DeviceCode.Equals(DeviceCode)).FirstAsync();
            try
            {
                RequestToUpdate.IsPublishingRequestCompleted = true;
                responseModel.Status = true;
                responseModel.SuccessMessage = "Ok";
                responseModel.Result = RequestToUpdate;
                await _dbContextClass.SaveChangesAsync();
                Console.WriteLine("API call received and Request updated to completed");
            }
            catch
            {
                responseModel.ErrorMessage = "Error : Unknown error occured";
                responseModel.Status = false;
            }
            return responseModel;

        }
        public async Task<ServiceResponseModel> GetStatusfromDeviceCodeAsync(string DeviceCode)
        {
            ServiceResponseModel serviceResponseModel = new ServiceResponseModel();
            var deviceExists = await _dbContextClass.tbl_Device_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).FirstOrDefaultAsync();
            var deviceToCheck = await _dbContextClass.tbl_Device_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).OrderByDescending(r => r.TimeStamp).FirstOrDefaultAsync();
            try
            {
                if (deviceExists != null)
                {
                    if (deviceToCheck.Status == true)
                    {
                        serviceResponseModel.SuccessMessage = "Status fetched as Error";
                        serviceResponseModel.Status = true;
                        serviceResponseModel.Result = true;
                    }
                    else if (deviceToCheck.Status == false)
                    {
                        serviceResponseModel.SuccessMessage = "Status fetched as OK";
                        serviceResponseModel.Status = true;
                        serviceResponseModel.Result = false;
                    }
                }
                else { serviceResponseModel.ErrorMessage = "Device does'nt exist"; serviceResponseModel.Status = false; }
            }
            catch
            {
                serviceResponseModel.ErrorMessage = "Cannot fetch Status";
                serviceResponseModel.Status = false;
            }
            return serviceResponseModel;
        }
        public async Task<ServiceResponseModel> UpdateStatusfromDeviceCodeAsync(string DeviceCode)
        {
            ServiceResponseModel responsemodel = new ServiceResponseModel();
            var deviceToUpdate = await _dbContextClass.tbl_Device_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).FirstOrDefaultAsync();
            try
            {
                if (deviceToUpdate != null)
                {
                    var updateStatusTableElements = new DeviceStatusEntity()
                    {
                        DeviceCode = deviceToUpdate.DeviceCode,
                        TimeStamp = DateTime.Now,
                        Status = !deviceToUpdate.Status
                    };
                    _dbContextClass.tbl_Device_Status.Add(updateStatusTableElements);
                    await _dbContextClass.SaveChangesAsync();
                }
                responsemodel.Status = true;
                responsemodel.Result = deviceToUpdate;
                responsemodel.SuccessMessage = "OK";
            }
            catch
            {
                responsemodel.Status = false;
                responsemodel.ErrorMessage = "Error";
            }
            
            
            return responsemodel;
        }
        public async Task<ServiceResponseModel> CheckDeviceActiveAsync(string DeviceCode)
        {
            ServiceResponseModel responseModel = new ServiceResponseModel();
            try
            {
                var deviceExists = await _dbContextClass.tbl_Device_Active_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).FirstOrDefaultAsync();
                var deviceToCheck = await _dbContextClass.tbl_Device_Active_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).OrderByDescending(r => r.TimeStamp).FirstOrDefaultAsync();
                if (deviceExists != null)
                {
                    if (deviceToCheck.IsRunning)
                    {
                        responseModel.Status = true;
                        responseModel.Result = true;
                        responseModel.SuccessMessage = "Device Is Active";
                    }
                    else
                    {
                        responseModel.Status = true;
                        responseModel.Result = false;
                        responseModel.SuccessMessage = "Device Is Inactive";
                    }
                }
                else
                {
                    responseModel.ErrorMessage = "Device does'nt exist";
                    responseModel.Status = false;
                }
                return responseModel;
            }
            catch
            {
                responseModel.ErrorMessage = "Cannot fetch Active Status";
                responseModel.Status = false;
            }
            return responseModel;
        }
        public async Task<ServiceResponseModel> UpdateDeviceActiveAsync(string DeviceCode)
        {
            ServiceResponseModel responsemodel = new ServiceResponseModel();
            var deviceExists = await _dbContextClass.tbl_Device_Active_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).FirstOrDefaultAsync();
            var deviceToUpdate = await _dbContextClass.tbl_Device_Active_Status.Where(r => r.DeviceCode.Equals(DeviceCode)).OrderByDescending(r => r.TimeStamp).FirstOrDefaultAsync();
            try
            {
                if (deviceExists != null)
                {
                    var updateActivityTableElements = new DeviceActivityEntity()
                    {
                        DeviceCode = deviceToUpdate.DeviceCode,
                        IsRunning = !deviceToUpdate.IsRunning,
                        TimeStamp = DateTime.Now,
                    };
                    _dbContextClass.tbl_Device_Active_Status.Add(updateActivityTableElements);

                    //deviceToUpdate.IsRunning = !deviceToUpdate.IsRunning;

                    //if (deviceToUpdate.IsRunning)
                    //{
                    //    deviceToUpdate.IsRunning = false;

                    //}
                    //else if(deviceToUpdate.IsRunning == false)
                    //{
                    //    deviceToUpdate.IsRunning = true;
                    //}

                    await _dbContextClass.SaveChangesAsync();

                    responsemodel.Status = true;
                    responsemodel.Result = "Device running Updated";
                    responsemodel.SuccessMessage = "OK";
                }
                else
                {
                    responsemodel.Status = false;
                    responsemodel.Result = "Device Not Found";
                    responsemodel.ErrorMessage = "Error";

                }
            }
            catch
            {
                responsemodel.Status = false;
                responsemodel.ErrorMessage = "Error";
            }
            return responsemodel;
        }
        public async Task<ServiceResponseModel> AddDataAsync(OutputModel model)
        {
            ServiceResponseModel responseModel = new ServiceResponseModel();
            try
            {
                var DeviceData = new DeviceDataEntity()
                {
                    DeviceCode = model.DeviceCode,
                    TimeStamp = model.TimeStamp,
                    X = model.X,
                    Y = model.Y,
                    Status = model.Status

                };
                _dbContextClass.tbl_Device_Data.Add(DeviceData);
                await _dbContextClass.SaveChangesAsync();
                responseModel.Status = true;
                responseModel.SuccessMessage = "Added Successfully";
                return responseModel;
            }
            catch
            {
                responseModel.ErrorMessage = "Error";
                responseModel.Status = false;
                return responseModel;
            }
        }

       
    }
}

