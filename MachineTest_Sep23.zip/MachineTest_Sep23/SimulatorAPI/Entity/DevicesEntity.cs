﻿using System.ComponentModel.DataAnnotations;

namespace SimulatorAPI.Entity
{
    public class DevicesEntity
    {
        [Key]
        public Guid Id { get; set; }
        public string DeviceCode {  get; set; }
        public string DeviceName { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public bool IsPublishingRequestCompleted {  get; set; }
    }
}
