﻿using System.ComponentModel.DataAnnotations;

namespace SimulatorAPI.Entity
{
    public class DeviceDataEntity
    {
        public Guid Id { get; set; }
        public string DeviceCode { get; set; }
        public DateTime TimeStamp {  get; set; }
        public float X {  get; set; }
        public float Y { get; set; }
        public bool Status {  get; set; }
    }
}
