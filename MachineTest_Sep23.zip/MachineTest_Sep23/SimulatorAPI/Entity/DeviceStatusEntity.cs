﻿using System.ComponentModel.DataAnnotations;

namespace SimulatorAPI.Entity
{
    public class DeviceStatusEntity
    {
        [Key]
        public Guid Id { get; set; }
        
        public string DeviceCode { get; set; }
        public DateTime TimeStamp { get; set; }
        public bool Status {  get; set; }

    }
}

