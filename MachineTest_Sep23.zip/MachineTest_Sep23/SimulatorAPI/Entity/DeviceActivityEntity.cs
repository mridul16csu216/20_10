﻿using System.ComponentModel.DataAnnotations;

namespace SimulatorAPI.Entity
{
    public class DeviceActivityEntity
    {
        [Key]
        public Guid Id { get; set; }
        public string DeviceCode {  get; set; }
        public bool IsRunning { get; set; }
        public DateTime TimeStamp { get; set; }
    }
}
