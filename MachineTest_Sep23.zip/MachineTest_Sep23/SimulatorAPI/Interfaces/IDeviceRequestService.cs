﻿using SimulatorAPI.Models.Request;
using SimulatorAPI.Models.Response;

namespace SimulatorAPI.Interfaces
{
    public interface IDeviceRequestService
    {
        Task<ServiceResponseModel> AddDeviceRequestAsync(DeviceRequestModel model);
        Task<ServiceResponseModel> GetPendingRequestsAsync();
        Task<ServiceResponseModel> UpdateRequestToCompletedAsync(string DeviceCode);
        Task<ServiceResponseModel> GetStatusfromDeviceCodeAsync(string DeviceCode);
        Task<ServiceResponseModel> UpdateStatusfromDeviceCodeAsync(string DeviceCode);
        Task<ServiceResponseModel> AddDataAsync(OutputModel model);
        Task<ServiceResponseModel> CheckDeviceActiveAsync(string DeviceCode);
        Task<ServiceResponseModel> UpdateDeviceActiveAsync(string DeviceCode);
    }
}
