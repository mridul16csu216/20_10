﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SimulatorAPI.Migrations
{
    /// <inheritdoc />
    public partial class Initial6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_Devices",
                table: "tbl_Devices");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_Device_Status",
                table: "tbl_Device_Status");

            migrationBuilder.AlterColumn<string>(
                name: "DeviceCode",
                table: "tbl_Devices",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "DeviceCode",
                table: "tbl_Device_Status",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_Devices",
                table: "tbl_Devices",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_Device_Status",
                table: "tbl_Device_Status",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_Devices",
                table: "tbl_Devices");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_Device_Status",
                table: "tbl_Device_Status");

            migrationBuilder.AlterColumn<string>(
                name: "DeviceCode",
                table: "tbl_Devices",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "DeviceCode",
                table: "tbl_Device_Status",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_Devices",
                table: "tbl_Devices",
                column: "DeviceCode");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_Device_Status",
                table: "tbl_Device_Status",
                column: "DeviceCode");
        }
    }
}
