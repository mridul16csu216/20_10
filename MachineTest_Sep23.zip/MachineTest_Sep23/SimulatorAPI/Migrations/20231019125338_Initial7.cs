﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SimulatorAPI.Migrations
{
    /// <inheritdoc />
    public partial class Initial7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_Device_Active_Status",
                columns: table => new
                {
                    DeviceCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    IsRunning = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Device_Active_Status", x => x.DeviceCode);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_Device_Active_Status");
        }
    }
}
