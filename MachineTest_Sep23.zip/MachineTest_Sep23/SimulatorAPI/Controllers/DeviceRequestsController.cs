﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SimulatorAPI.Interfaces;
using SimulatorAPI.Models.Request;
using SimulatorAPI.Models.Response;
using SimulatorAPI.Services;

namespace SimulatorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceRequestsController : ControllerBase
    {
        private readonly IDeviceRequestService _deviceRequestService;
        public DeviceRequestsController(IDeviceRequestService deviceRequestService)
        {
            _deviceRequestService = deviceRequestService;
        }

        [HttpPost("AddRequest")]

        public async Task<ObjectResult> AddRequest(DeviceRequestModel deviceRequestModel)
        {
            var result = await _deviceRequestService.AddDeviceRequestAsync(deviceRequestModel);
            return StatusCode(result.StatusCode, result);
        }

        [HttpGet("Requests")]
        public async Task<ObjectResult> CheckForIncompleteRequests()
        {
            var result = await _deviceRequestService.GetPendingRequestsAsync();
            return StatusCode(result.StatusCode, result);
        }
        [HttpPost("UpdateCompletedRequest/{Id}")]
        public async Task<ObjectResult> UpdateCompletedRequestsInDB([FromRoute] string DeviceCode)
        {
            var result = await _deviceRequestService.UpdateRequestToCompletedAsync(DeviceCode);
            return StatusCode(result.StatusCode, result);
        }

        [HttpGet("GetStatusforDeviceCode/{DeviceCode}")]
        public async Task<ObjectResult> CheckStatusForDeviceCode([FromRoute] string DeviceCode)
        {
            var result = await _deviceRequestService.GetStatusfromDeviceCodeAsync(DeviceCode);
            return StatusCode(result.StatusCode, result);
        }

        [HttpPost("UpdateStatusfromDeviceCode/{DeviceCode}")]
        public async Task<ObjectResult> UpdateStatus([FromRoute] string DeviceCode)
        {
            var result = await _deviceRequestService.UpdateStatusfromDeviceCodeAsync(DeviceCode);
            return StatusCode(result.StatusCode, result);
        }

        [HttpPost("DeviceData")]
        public async Task<ObjectResult> AddDataToDB(OutputModel outputModel)
        {
            var result = await _deviceRequestService.AddDataAsync(outputModel);
            return StatusCode(result.StatusCode, result);
        }
        [HttpGet("GetActivityforDeviceCode/{DeviceCode}")]
        public async Task<ObjectResult> CheckDeviceActive([FromRoute] string DeviceCode)
        {
            var result = await _deviceRequestService.CheckDeviceActiveAsync(DeviceCode);
            return StatusCode(result.StatusCode, result);
        }
        [HttpPost("UpdateActivityforDeviceCode/{DeviceCode}")]
        public async Task<ObjectResult> UpdateDeviceActive([FromRoute] string DeviceCode)
        {
            var result = await _deviceRequestService.UpdateDeviceActiveAsync(DeviceCode);
            return StatusCode(result.StatusCode, result);
        }


        //[HttpPost("UpdateCompletedRequest/{Id}")]
        //public async Task<ObjectResult> UpdateCompletedRequestsInDB([FromRoute] Guid Id)
        //{
        //    var result = await _publishRequestServices.UpdateRequestToCompletedAsync(Id);
        //    return StatusCode(result.StatusCode, result);
        //}
    }
}
